var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var courses_exports = {};
__export(courses_exports, {
  createCourse: () => createCourse,
  deleteCourse: () => deleteCourse,
  getCourseById: () => getCourseById,
  getCourses: () => getCourses,
  updateCourse: () => updateCourse
});
module.exports = __toCommonJS(courses_exports);
var import_course = __toESM(require("../models/course.js"), 1);
var import_participationStatus = require("../models/participationStatus.js");
var import_participation = __toESM(require("../models/participation.js"), 1);
const getCourses = async (req, res) => {
  try {
    const courses = await import_course.default.find().populate("category formateur").exec();
    res.json(courses);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server Error" });
  }
};
const getCourseById = async (req, res, next) => {
  try {
    console.log(`Received request to get course with ID: ${req.params.courseId}`);
    const course = await import_course.default.findOne({ "_id": req.params.courseId }).populate("formateur").populate("category");
    if (!course) {
      return res.status(404).json({ message: "Course not found" });
    }
    const participation = await import_participation.default.findOne({ "course": req.params.courseId, "etudiant": req.user.id });
    const isUserParticipated = participation ? participation.approved : import_participationStatus.ParticipationStatus.isNotSubscribed;
    return res.json({ ...course._doc, isParticipated: isUserParticipated });
  } catch (error) {
    return res.status(500).json({ message: "An error occurred", error: error.message });
  }
};
const createCourse = async (req, res) => {
  const newCourse = new import_course.default(req.body);
  try {
    const savedCourse = await newCourse.save();
    res.status(201).json(savedCourse);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server Error" });
  }
};
const updateCourse = async (req, res) => {
  const courseId = req.params.courseId;
  try {
    const updatedCourse = await import_course.default.findByIdAndUpdate(courseId, req.body, { new: true });
    if (!updatedCourse) {
      return res.status(404).json({ message: "Course not found" });
    }
    res.json(updatedCourse);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server Error" });
  }
};
const deleteCourse = async (req, res) => {
  const courseId = req.params.courseId;
  try {
    const deletedCourse = await import_course.default.findByIdAndDelete(courseId);
    if (!deletedCourse) {
      return res.status(404).json({ message: "Course not found" });
    }
    res.json({ message: "Course deleted successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server Error" });
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  createCourse,
  deleteCourse,
  getCourseById,
  getCourses,
  updateCourse
});
