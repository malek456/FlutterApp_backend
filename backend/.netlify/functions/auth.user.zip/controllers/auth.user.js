var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var auth_user_exports = {};
__export(auth_user_exports, {
  GoogleLogin: () => GoogleLogin,
  login: () => login,
  register: () => register
});
module.exports = __toCommonJS(auth_user_exports);
var import_user = __toESM(require("../models/user.js"), 1);
var import_bcrypt = __toESM(require("bcrypt"), 1);
var import_jsonwebtoken = __toESM(require("jsonwebtoken"), 1);
var import_dotenv = __toESM(require("dotenv"), 1);
var import_authMiddleware = require("../middlewares/authMiddleware.js");
import_dotenv.default.config();
const login = async (req, res) => {
  const { email, password } = req.body;
  import_user.default.findOne({ email }).then((user) => {
    if (user) {
      import_bcrypt.default.compare(password, user.password, function(err, result) {
        if (err) {
          res.json({ status: "error", message: err });
        }
        if (result) {
          const hash = {
            id: user._id,
            role: user.role
          };
          const accessToken = (0, import_authMiddleware.generateAccessToken)(hash);
          res.status(200).send(JSON.stringify({
            //200 OK
            status: "success",
            message: "logged in successfully",
            user: {
              _id: user._id,
              firstName: user.firstName,
              lastName: user.lastName,
              username: user.username,
              gender: user.gender,
              email: user.email,
              password: user.password,
              phone: user.phone,
              role: user.role,
              token: accessToken
            }
          }));
        } else {
          res.status(200).send(JSON.stringify({
            //201 password
            status: "error",
            message: "incorrect password"
          }));
        }
      });
    } else {
      res.status(200).send(JSON.stringify({
        //200 OK
        status: "error",
        message: "user not found"
      }));
    }
  });
};
const register = async (req, res) => {
  const { firstName, lastName, email, password } = req.body;
  try {
    let existingUser = await import_user.default.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: "User already exists" });
    }
    const hashedPassword = await import_bcrypt.default.hash(password, 10);
    const newUser = new import_user.default({
      firstName,
      lastName,
      email,
      password: hashedPassword
      // Add other fields as needed
    });
    const savedUser = await newUser.save();
    res.status(201).json(savedUser);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server Error" });
  }
};
const GoogleLogin = async (req, res) => {
  try {
    const userData = req.body;
    let user = await import_user.default.findOne({ email: userData.email });
    if (!user) {
      user = new import_user.default({
        password: userData.password,
        // Assuming you store uid as password (adjust as needed)
        firstName: userData.displayName,
        email: userData.email
        // Add more fields as needed
      });
      await user.save();
      console.log("New user created:", user);
    }
    res.status(200).json({ message: "User data processed successfully" });
  } catch (err) {
    console.error("Error processing user data:", err);
    res.status(500).json({ error: "Internal server error" });
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  GoogleLogin,
  login,
  register
});
