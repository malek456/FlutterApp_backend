var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var course_exports = {};
__export(course_exports, {
  default: () => course_default
});
module.exports = __toCommonJS(course_exports);
var import_mongoose = require("mongoose");
var import_lecture_schema = __toESM(require("./lecture.schema.js"), 1);
const courseSchema = new import_mongoose.Schema({
  title: { type: String },
  description: { type: String },
  images: [String],
  price: { type: String },
  category: {
    type: import_mongoose.Schema.ObjectId,
    ref: "categories"
  },
  formateur: {
    type: import_mongoose.Schema.ObjectId,
    ref: "users"
  },
  lectures: [import_lecture_schema.default],
  duration: { type: String },
  level: { type: String }
}, { timestamps: true });
const Course = (0, import_mongoose.model)("courses", courseSchema);
var course_default = Course;
