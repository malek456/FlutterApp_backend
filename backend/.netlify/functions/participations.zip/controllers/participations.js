var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var participations_exports = {};
__export(participations_exports, {
  getParticipationByUser: () => getParticipationByUser,
  requestParticipation: () => requestParticipation
});
module.exports = __toCommonJS(participations_exports);
var import_participationStatus = require("../models/participationStatus.js");
var import_participation = __toESM(require("../models/participation.js"), 1);
var import_course = __toESM(require("../models/course.js"), 1);
const requestParticipation = async (req, res) => {
  try {
    const course = await import_course.default.findById(req.params.courseId).populate("formateur").populate("category");
    if (!course) {
      return res.status(404).json({ message: "Course not found" });
    }
    const participation = new import_participation.default({
      course: req.params.courseId,
      formateur: course.formateur._id,
      etudiant: req.user.id,
      approved: import_participationStatus.ParticipationStatus.pending
    });
    const savedParticipation = await participation.save();
    res.status(201).json({
      status: "success",
      message: "Course enrolled!",
      data: savedParticipation
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: "error",
      message: "An error occurred when adding participation!"
    });
  }
};
const getParticipationByUser = async (req, res) => {
  const userId = req.params.userId;
  try {
    const participations = await import_participation.default.find({ etudiant: userId }).populate("course").populate("formateur");
    if (!participations.length) {
      return res.status(404).json({ message: "No participations found for this user" });
    }
    res.json(participations);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server Error" });
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getParticipationByUser,
  requestParticipation
});
